import setuptools

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setuptools.setup(
    name="pkg-Samir-Tanfous", # Replace with your own username
    version="0.0.1",
    author="Samir Tanfous",
    author_email="samir.tanfous@gmail.com",
    description="RUN NLU pipeline",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://github.com/samirt8/NLU_project",
    packages=setuptools.find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires='>=3.6',
)
